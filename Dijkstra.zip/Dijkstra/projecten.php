<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Beheer</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="header-left">
            <img src="Dijkstra.png" alt="Logo">
            <span>Dijkstra Draisma / Project Beheer</span>
        </div>
        <div class="header-right">
            <button onclick="window.location.href='profile.php'">Profiel</button>
        </div>
    </header>
    <main>
        <h1>Opgeslagen projecten</h1>
        <button id="deleteSelected">🗑️ Verwijder geselecteerde</button>
        <form id="addProjectForm">
        </form>
        <table>
            <thead>
                <tr>
                    <th></th>
                    <th>Projecten</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="projectList">
                <!-- Project rows will be dynamically added here -->
            </tbody>
        </table>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadProjects();

            document.getElementById('deleteSelected').addEventListener('click', function() {
                deleteSelectedProjects();
            });

            document.getElementById('addProjectForm').addEventListener('submit', function(e) {
                e.preventDefault();
                addProject();
            });
        });

        function loadProjects() {
            fetch('fetch_projects.php')
                .then(response => response.json())
                .then(projects => {
                    let projectList = document.getElementById('projectList');
                    projectList.innerHTML = '';
                    projects.forEach(project => {
                        let row = document.createElement('tr');
                        row.innerHTML = `
                            <td><input type="checkbox" class="selectProject" data-id="${project.DesignID}"></td>
                            <td>${project.DesignName}</td>
                            <td><button class="edit" onclick="editProject(${project.DesignID})">✏️</button></td>
                            <td><button class="delete" onclick="deleteProject(${project.DesignID})">🗑️</button></td>
                        `;
                        projectList.appendChild(row);
                    });
                });
        }

        function addProject() {
            let newProjectName = document.getElementById('newProjectName').value;

            fetch('add_project.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ name: newProjectName })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('newProjectName').value = '';
                    loadProjects();
                } else {
                    alert('Failed to add project');
                }
            });
        }

        function editProject(id) {
            let newName = prompt('Enter new project name');
            if (newName) {
                fetch('edit_project.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ id: id, name: newName })
                }).then(() => loadProjects());
            }
        }

        function deleteProject(id) {
            fetch('delete_project.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ id: id })
            }).then(() => loadProjects());
        }

        function deleteSelectedProjects() {
            let selectedProjects = document.querySelectorAll('.selectProject:checked');
            selectedProjects.forEach(project => {
                let id = project.getAttribute('data-id');
                deleteProject(id);
            });
        }
    </script>
</body>
</html>
