<?php
include 'db_config.php';

$customer_id = 1; // Replace with the actual customer ID, probably from session

$stmt = $conn->prepare("SELECT DesignID, DesignName FROM design WHERE CustomerID = :customer_id");
$stmt->bindParam(':customer_id', $customer_id);
$stmt->execute();
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($projects);
?>
