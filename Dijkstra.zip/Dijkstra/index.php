<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
<h2>Welcome to Secure Login</h2>
    <a href="register.php">Register</a> | <a href="login.php">Login</a>
   
</body>
</html>