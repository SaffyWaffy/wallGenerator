<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $new_password = $_POST['new_password'];

    // Check if the token is valid and not expired
    $stmt = $conn->prepare("SELECT * FROM password_reset_tokens WHERE Token = :token AND Expiry > NOW()");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $reset_request = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($reset_request) {
        // Get the user's ID
        $customer_id = $reset_request['CustomerID'];

        // Generate a new salt and hash the new password
        $salt = bin2hex(random_bytes(16));
        $hashed_password = password_hash($new_password . $salt, PASSWORD_BCRYPT);

        // Update the user's password
        $stmt = $conn->prepare("UPDATE Customer SET CustomerPasswordHash = :password_hash, CustomerPasswordSalt = :salt WHERE CustomerID = :customer_id");
        $stmt->bindParam(':password_hash', $hashed_password);
        $stmt->bindParam(':salt', $salt);
        $stmt->bindParam(':customer_id', $customer_id);

        if ($stmt->execute()) {
            // Delete the token after successful password reset
            $stmt = $conn->prepare("DELETE FROM password_reset_tokens WHERE Token = :token");
            $stmt->bindParam(':token', $token);
            $stmt->execute();

            echo "Your password has been successfully reset.";
        } else {
            echo "Failed to reset password.";
        }
    } else {
        echo "Invalid or expired token.";
    }
} elseif (isset($_GET['token'])) {
    $token = $_GET['token'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('Achtergrond.jpg'); /* Vervang 'achtergrond.jpg' met het pad naar je afbeelding */
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif; /* Als voorbeeld van een lettertype */
        }
    </style>
</head>
<body>
<div class="login-container">
        <div class="login-box">
            <div class="header-container">
                <div class="close-button">X</div>
            </div>
            <div class="top-container">
                <div class="inloggen-container">
                    <h2>Reset wachtwoord</h2>
                </div>
                <div class="logo-container">
                    <img src="Dijkstra.png" alt="Logo" class="logo">
                </div>
            </div>

    <form method="POST" action="" id="resetForm">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        Nieuw wachtwoord: <input type="password" name="new_password" id="new_password" required><br>
        Bevestig nieuw wachtwoord: <input type="password" name="confirm_password" id="confirm_password" required><br>
        <input type="submit" value="Reset Password">
    </form>
</body>
<script>
    document.getElementById("resetForm").onsubmit = function() {
        var newPassword = document.getElementById("new_password").value;
        var confirmPassword = document.getElementById("confirm_password").value;

        if (newPassword != confirmPassword) {
            alert("Wachtwoord komt niet overeen");
            return false;
        }
    }
</script>
</html>

<?php
} else {
    echo "Invalid request.";
}
?>
