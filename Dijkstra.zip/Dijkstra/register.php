<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Generate a salt and hash the password
    $salt = bin2hex(random_bytes(16));
    $hashed_password = password_hash($password . $salt, PASSWORD_BCRYPT);

    // Insert user into the database
    $stmt = $conn->prepare("INSERT INTO Customer (CustomerName, CustomerEmail, CustomerPasswordHash, CustomerPasswordSalt) VALUES (:name, :email, :password_hash, :salt)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password_hash', $hashed_password);
    $stmt->bindParam(':salt', $salt);

    if ($stmt->execute()) {
        echo "Registration successful.";
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .bodys {
            margin: 0;
            padding: 0;
            background-image: url('Achtergrond.jpg'); /* Vervang 'achtergrond.jpg' met het pad naar je afbeelding */
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif; /* Als voorbeeld van een lettertype */
        }
    </style>
</head>
<body class="bodys">
    <div class="login-container">
        <div class="login-box">
            <div class="header-container">
                <div class="close-button">X</div>
            </div>
            <div class="top-container">
                <div class="inloggen-container">
                <h2 class="htwee">Register</h2>
                </div>
                <div class="logo-container">
                </div>
            </div>
            <form class="forms" method="POST" action="">
                <label class="labels" for="name">Volledige naam:</label>
                <input class="inputs" type="text" id="name" name="name" required><br>
                <label class="labels" for="email">Email:</label>
                <input class="labels" type="email" id="email" name="email" required><br>
                <label class="labels" for="password">Wachtwoord:</label>
                <input class="inputs" type="password" id="password" name="password" required><br>
                <input class="inputs" type="submit" value="Register">
            </form> 
            <p class="paragraaf">Heeft al een account? <a class="anker" href="login.php">Log hier in!</a></p>
        </div>
    </div>
</body>
</html>
