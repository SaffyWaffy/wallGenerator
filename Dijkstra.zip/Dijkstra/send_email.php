<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function sendVerificationEmail($toEmail, $token) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'WallGeneratorDijkstraDraisma@gmail.com'; // Your Gmail address
        $mail->Password = 'avlp qxdn ocnp inax'; // Your Gmail password or App password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('WallGeneratorDijkstraDraisma@gmail.com', 'Your Name'); // Update this
        $mail->addAddress($toEmail);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset Request';
        $resetLink = "localhost/Dijkstra/reset_password.php?token=" . $token; // Ensure this is the correct URL
        $mail->Body = "Click on this link to reset your password: <a href=\"$resetLink\">$resetLink</a>";
        $mail->AltBody = "Click on this link to reset your password: $resetLink";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer Error: ' . $mail->ErrorInfo);
        return false;
    }
}
?>
