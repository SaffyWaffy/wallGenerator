<?php
include 'db_config.php';

try {
    $stmt = $conn->prepare("SELECT StoneTypeID, StoneTypeName FROM stonetype");
    $stmt->execute();

    $stoneTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($stoneTypes);
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
