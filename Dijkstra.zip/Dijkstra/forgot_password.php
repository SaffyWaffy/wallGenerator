<?php
include 'db_config.php';
require 'send_email.php'; // Make sure this file is included to use the sendVerificationEmail function

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM Customer WHERE CustomerEmail = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Generate a unique token
        $token = bin2hex(random_bytes(50));
        $expiry = date("Y-m-d H:i:s", strtotime('+1 hour'));

        // Store the token in the database with an expiry time
        $stmt = $conn->prepare("INSERT INTO password_reset_tokens (CustomerID, Token, Expiry) VALUES (:customer_id, :token, :expiry)");
        $stmt->bindParam(':customer_id', $user['CustomerID']);
        $stmt->bindParam(':token', $token);
        $stmt->bindParam(':expiry', $expiry);
        $stmt->execute();

        // Send the verification email
        if (sendVerificationEmail($email, $token)) {
            $message = 'Een Email om je wachtwoord te veranderen is verstuurd naar je Email.';
        } else {
            $message = 'Email versturen gevaald.';
        }
    } else {
        $message = 'Email niet gevonden.';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('Achtergrond.jpg'); /* Vervang 'achtergrond.jpg' met het pad naar je afbeelding */
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif; /* Als voorbeeld van een lettertype */
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <div class="header-container">
            <div class="close-button">X</div>
        </div>
        <div class="top-container">
            <div class="inloggen-container">
                <h2>Wachtwoord vergeten</h2>
            </div>
            <div class="logo-container">
                <img src="Dijkstra.png" alt="Logo" class="logo">
            </div>
        </div>
        <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { ?>
            <p><?php echo $message; ?></p>
        <?php } else { ?>
            <form method="POST" action="">
                Vul je email in: <input type="email" name="email" required><br>
                <input type="submit" value="Versturen">
            </form>
        <?php } ?>
    </div>
</div>
</body>
</html>
