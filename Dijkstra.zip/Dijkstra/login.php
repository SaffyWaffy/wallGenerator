<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .bodys {
            margin: 0;
            padding: 0;
            background-image: url('Achtergrond.jpg'); /* Vervang 'achtergrond.jpg' met het pad naar je afbeelding */
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif; /* Als voorbeeld van een lettertype */
        }
    </style>
</head>
<body class="bodys">
<div class="login-container">
    <div class="login-box">
        <div class="header-container">
            <div class="close-button">X</div>
        </div>
        <div class="top-container">
            <div class="inloggen-container">
                <h2 class="htwee">Inloggen</h2>
            </div>
            <div class="logo-container">
               
            </div>
        </div>
       
        <form class="forms" method="POST" action="">
            <label class="labels" for="email">Email adres:</label>
            <input class="inputs" type="email" id="email" name="email" required><br>
            <label class="labels" for="password">Wachtwoord:</label>
            <input class="inputs" type="password" id="password" name="password" required><br>
            <p class="paragraaf"><a class="anker" href="forgot_password.php">Wachtwoord vergeten? </a></p>
            <input class="inputs" type="submit" value="Inloggen">
        </form> 
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $email = $_POST['email'];
            $password = $_POST['password'];
        
            // Retrieve user from the database
            $stmt = $conn->prepare("SELECT * FROM Customer WHERE CustomerEmail = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if ($user && password_verify($password . $user['CustomerPasswordSalt'], $user['CustomerPasswordHash'])) {
                echo "Login successful. Welcome " . htmlspecialchars($user['CustomerName']);
            } else {
                echo "Incorrecte email of wachtwoord";
            }
        }
        ?>
        <p class="paragraaf">Heeft u nog geen account? <a class="anker" href="register.php">Registreer hier!</a></p>
    </div>
</div>
</body>
</html>
