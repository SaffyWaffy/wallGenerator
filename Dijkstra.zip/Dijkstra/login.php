<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('Achtergrond.jpg'); /* Vervang 'achtergrond.jpg' met het pad naar je afbeelding */
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif; /* Als voorbeeld van een lettertype */
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <div class="header-container">
            <div class="close-button">X</div>
        </div>
        <div class="top-container">
            <div class="inloggen-container">
                <h2>Inloggen</h2>
            </div>
            <div class="logo-container">
                <img src="Dijkstra.png" alt="Logo" class="logo">
            </div>
        </div>
       
        <form method="POST" action="">
            <label for="email">Email adres:</label>
            <input type="email" id="email" name="email" required><br>
            <label for="password">Wachtwoord:</label>
            <input type="password" id="password" name="password" required><br>
            <p><a href="forgot_password.php">Wachtwoord vergeten? </a></p>
            <input type="submit" value="Inloggen">
        </form> 
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $email = $_POST['email'];
            $password = $_POST['password'];
        
            // Retrieve user from the database
            $stmt = $conn->prepare("SELECT * FROM Customer WHERE CustomerEmail = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if ($user && password_verify($password . $user['CustomerPasswordSalt'], $user['CustomerPasswordHash'])) {
                echo "Login successful. Welcome " . htmlspecialchars($user['CustomerName']);
            } else {
                echo "Incorrecte email of wachtwoord";
            }
        }
        ?>
        <p>Heeft u nog geen account? <a href="register.php">Registreer hier!</a></p>
    </div>
</div>
</body>
</html>
