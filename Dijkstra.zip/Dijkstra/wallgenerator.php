<!DOCTYPE html>
<html>
<head>
    <title>Wall Generator</title>
    <style>
        .container {
            display: flex;
        }
        .form-container {
            flex: 1;
        }
        .canvas-container {
            flex: 2;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        #canvas {
            border: 2px solid black;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-container">
        <h2>Filters:</h2>
        <label for="stoneType">Steensoorten:</label>
        <select id="stoneType">
            <!-- Stone types will be populated here -->
        </select>
        <h2>Muur formaten</h2>
        <label for="wallWidth">Breedte (mm):</label>
        <input type="number" id="wallWidth" value="3000">
        <label for="wallHeight">Hoogte (mm):</label>
        <input type="number" id="wallHeight" value="2000">
        <h2>Voeg afmeting</h2>
        <label for="horizontalMortar">Horizontaal (mm):</label>
        <input type="number" id="horizontalMortar" value="10">
        <label for="verticalMortar">Verticaal (mm):</label>
        <input type="number" id="verticalMortar" value="10">
        <h2>Sparing</h2>
        <button onclick="addGap()">Sparing toevoegen</button>
        <br><br>
        <button onclick="draw()">Opslaan</button>
        <p>Om het project op te slaan moet u inloggen.</p>
    </div>
    <div class="canvas-container">
        <canvas id="canvas"></canvas>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    fetchStoneTypes();
    draw();
    addReactiveListeners();
});

function fetchStoneTypes() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "fetch_stone_types.php", true);
    xhr.onload = function() {
        if (this.status === 200) {
            const stoneTypes = JSON.parse(this.responseText);
            const stoneTypeSelect = document.getElementById('stoneType');
            stoneTypes.forEach(function(stone) {
                const option = document.createElement('option');
                option.value = stone.StoneTypeID;
                option.textContent = stone.StoneTypeName;
                stoneTypeSelect.appendChild(option);
            });
        }
    }
    xhr.send();
}

function draw() {
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    
    // Get user inputs
    const steenDxMm = 210; // Brick length in mm
    const steenDyMm = 50;  // Brick height in mm
    const voegDxMm = parseFloat(document.getElementById('horizontalMortar').value); // Horizontal mortar in mm
    const voegDyMm = parseFloat(document.getElementById('verticalMortar').value);   // Vertical mortar in mm
    const muurDxMm = parseFloat(document.getElementById('wallWidth').value); // Wall width in mm
    const muurDyMm = parseFloat(document.getElementById('wallHeight').value); // Wall height in mm

    // Fixed brick and mortar sizes in pixels
    const steenDxPx = 60; // Fixed brick length in pixels
    const steenDyPx = 14;  // Fixed brick height in pixels
    const voegDxPx = 3;    // Fixed horizontal mortar in pixels
    const voegDyPx = 3;    // Fixed vertical mortar in pixels

    // Calculate canvas dimensions based on wall size
    const canvasWidth = Math.min(window.innerWidth * 0.9, (muurDxMm / steenDxMm * (steenDxPx + voegDxPx)));
    const canvasHeight = Math.min(window.innerHeight * 0.9, (muurDyMm / steenDyMm * (steenDyPx + voegDyPx)));

    // Adjust canvas size if wall is smaller
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    // Clear previous drawing
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw the wall from the bottom left
    let row = 0;
    for (let ypos = canvas.height - steenDyPx; ypos >= 0; ypos -= (steenDyPx + voegDyPx)) {
        let offset = (row % 2 === 0) ? 0 : steenDxPx / 2;
        for (let xpos = -offset; xpos < canvas.width; xpos += (steenDxPx + voegDxPx)) {
            // Calculate remaining space at the end of the row
            let remainingSpace = canvas.width - (xpos + steenDxPx);
            let brickWidthPx = remainingSpace < 0 ? steenDxPx + remainingSpace : steenDxPx;

            // Draw brick with adjusted width
            ctx.strokeRect(xpos, ypos, brickWidthPx, steenDyPx);
        }
        row++;
    }
}

function addReactiveListeners() {
    const inputs = document.querySelectorAll('#wallWidth, #wallHeight, #horizontalMortar, #verticalMortar');
    inputs.forEach(input => {
        input.addEventListener('input', draw);
    });
}

function addGap() {
    // Implement the functionality to add gaps (sparings) in the wall
}
</script>
</body>
</html>
